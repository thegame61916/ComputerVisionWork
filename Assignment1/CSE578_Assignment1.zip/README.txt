IMG_5455.JPG : for DLT and RANSAC based estimation; 
measurement.JPG : Measurements are shown according to scale(in mms). 
		  World co-ordinate of every point can be calculated using the unit measurements given from the origin. 

IMG_5456.JPG-IMG_5470.JPG : for Zhang algorithm based estimation
			    Size of each square on checkerboard 29mmX29mm